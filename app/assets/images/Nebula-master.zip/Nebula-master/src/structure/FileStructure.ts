export interface FileStructure {

    init(): Promise<void>

}
