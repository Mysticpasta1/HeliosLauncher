export interface Asset {

    url: string
    path: string
    size: number
    hashType: string
    hash: string

}
