export enum LibraryType {

    FORGE = 'FORGE'

}