import { McModInfo } from './McModInfo.js'

export interface McModInfoList {

    modListVersion: number
    modList: McModInfo[]
}
