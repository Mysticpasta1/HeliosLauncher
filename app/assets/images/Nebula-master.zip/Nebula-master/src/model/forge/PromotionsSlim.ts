export interface PromotionsSlim {

    homepage: string
    promos: {
        [id: string]: string
    }

}
